<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku_model extends CI_Model
{
    public function simpan_data($data)
    {
        return $this->db->insert('buku', $data);
    }

    public function find()
    {
        return $this->db
            ->from('buku')
            ->order_by('kode_buku', 'ASC')
            ->get()
            ->result();
    }

    public function findById($id)
    {
        return $this->db
            ->from('buku')
            ->where('id', $id)
            ->get()
            ->row();
    }

    public function update($id, $data)
    {
        return $this->db
            ->where('id', $id)
            ->update('buku', $data);
    }

    public function delete($id)
    {
        return $this->db
            ->where('id', $id)
            ->delete('buku');
    }
}
