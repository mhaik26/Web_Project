<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman_model extends CI_Model {

    function findAnggota()
    {
        $this->db->select("anggota.*, users.nama");
        $this->db->from('anggota');
        $this->db->join("users", "users.id = anggota.user_id");
        $this->db->where('status', 'aktif');
        $this->db->order_by('users.id', 'ASC');

        $query = $this->db->get()->result();
        return $query;
    }

    function findBuku()
    {
        $this->db->from('buku');
        $this->db->order_by('kode_buku', 'ASC');

        $query = $this->db->get()->result();
        return $query;
    }

    function simpan_data_peminjaman($data)
    {
        $this->db->insert('peminjaman', $data);
        return $this->db->insert_id();
    }

    function simpan_data_peminjaman_detail($data)
    {
        $query = $this->db->insert('peminjaman_detail', $data);
        return $query;
    }

    function delete($peminjaman_id)
    {
        $this->db->trans_start();

        // Hapus tabel child dulu
        $this->db->where('peminjaman_id', $peminjaman_id);
        $this->db->delete('peminjaman_detail');

        // Hapus tabel parent
        $this->db->where('id', $peminjaman_id);
        $this->db->delete('peminjaman');

        $this->db->trans_complete();

        return $this->db->trans_status();
    }
}
