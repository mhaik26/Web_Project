<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Tuliskan Nama Kalian atas tugas ini</title> 
    <style> 
         
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        } 
 
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
        } 
 
        header { 
            background-color: #333; 
            color: #fff; 
            padding: 20px 0; 
            text-align: center; 
        } 
 
        nav { 
            display: flex; 
            justify-content: center; 
            background-color: #444; 
        } 
 
        nav a { 
            color: white; 
            padding: 15px 20px; 
            text-decoration: none; 
            display: block; 
        } 
 
        nav a:hover { 
            background-color: #555; 
        } 
 
 
 
 
        section { 
            padding: 40px 20px; 
            text-align: center; 
        } 
 
        #home { 
            background: #f4f4f4; 
        } 
 
        #about { 
            background: #e2e2e2; 
        } 
 
        #services { 
            background: #d0d0d0; 
        } 
 
        #contact { 
            background: #bdbdbd; 
        } 
 
        footer { 
            background: #333; 
            color: #fff; 
            padding: 10px; 
            text-align: center; 
        } 
 
        /* Responsive Design */ 
        @media (max-width: 600px) { 
            nav { 
                flex-direction: column; 
            } 
 
            nav a { 
                text-align: center; 
                padding: 10px; 
            } 
 
            section { 
                padding: 20px 10px; 
            } 
        } 
    </style> 
</head> 
 
<body> 
 
    <header> 
        <h1>My One Page Website</h1> 
        <p>Welcome to our responsive single-page site</p> 
    </header> 
    <nav> 
        <a href="#home">Home</a> 
        <a href="#about">About</a> 
        <a href="#services">Services</a> 
        <a href="#contact">Contact</a> 
    </nav> 
 
    <section id="home"> 
        <h2>Home</h2> 
        <p>This is the home section of our one-page responsive site.</p> 
    </section> 
 
    <section id="about"> 
        <h2>About</h2> 
        <p>We are a small team passionate about building simple and clean 
websites.</p> 
    </section> 
 
    <section id="services"> 
        <h2>Services</h2> 
        <p>We offer web development, design, and consulting services.</p> 
    </section> 
 
    <section id="contact"> 
        <h2>Contact</h2> 
        <p>Email us at <a 
href="mailto:info@example.com">info@example.com</a></p> 
    </section> 
<footer> 
<p>&copy; 2025 My Company. All rights reserved.</p> 
</footer> 
</body> 
</html>