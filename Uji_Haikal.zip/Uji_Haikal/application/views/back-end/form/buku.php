<section class="content-header">
    <div class="container-fluid">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Data Buku Perpustakaan</h3>
            </div>

            <div class="card-body">
                <div class="row">

                    <!-- FORM -->
                    <div class="col-lg-4">
                        <form id="form-buku">
                            <div class="form-group">
                                <label>Kode Buku</label>
                                <input type="text" class="form-control form-control-sm form-control-border" id="kode_buku" name="kode_buku">
                                <input type="hidden" id="id_buku" name="id_buku">
                            </div>

                            <div class="form-group">
                                <label>Judul</label>
                                <input type="text" class="form-control form-control-sm form-control-border" id="judul" name="judul">
                            </div>

                            <div class="form-group">
                                <label>Pengarang</label>
                                <input type="text" class="form-control form-control-sm form-control-border" id="pengarang" name="pengarang">
                            </div>

                            <div class="form-group">
                                <label>Penerbit</label>
                                <input type="text" class="form-control form-control-sm form-control-border" id="penerbit" name="penerbit">
                            </div>

                            <div class="form-group">
                                <label>Tahun</label>
                                <input type="text" class="form-control form-control-sm form-control-border" id="tahun" name="tahun">
                            </div>

                            <div class="form-group">
                                <label>Stok</label>
                                <input type="number" class="form-control form-control-sm form-control-border" id="stok" name="stok">
                            </div>
                        </form>

                        <div class="form-group d-flex justify-content-end">
                            <button class="btn btn-sm btn-primary" id="btn-simpan">
                                <i class="fa fa-save"></i> Simpan
                            </button>

                            <button type="button" class="btn btn-sm btn-primary ml-1" id="btn-update" style="display:none;">
                                <i class="fa fa-save"></i> Update
                            </button>

                            <button type="button" class="btn btn-sm btn-success ml-1" id="btn-refresh" style="display:none;">
                                <i class="fa fa-retweet"></i> Refresh
                            </button>
                        </div>
                    </div>

                    <!-- TABLE -->
                    <div class="col-lg-8">
                        <div class="table-responsive">
                            <table id="DataTables" class="table table-striped" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Buku</th>
                                        <th>Tahun</th>
                                        <th>Stok</th>
                                        <th width="20%">#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; foreach ($result as $rs): ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td>
                                                <b><?= $rs->kode_buku ?></b><br>
                                                <?= $rs->judul ?><br>
                                                <?= $rs->pengarang ?><br>
                                                <?= $rs->penerbit ?>
                                            </td>
                                            <td><?= $rs->tahun ?></td>
                                            <td><?= $rs->stok ?></td>
                                            <td>
                                                <!-- EDIT -->
                                                <button class="btn btn-sm btn-primary"
                                                    onclick="edit('<?= $rs->id ?>')">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <!-- HAPUS -->
                                                <button class="btn btn-sm btn-danger"
                                                    onclick="hapus('<?= $rs->id ?>')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(document).ready(function () {

    $('#DataTables').DataTable({
        paging: true,
        ordering: false,
        responsive: true,
        buttons: ["copy", "csv", "excel", "pdf", "print", "colvis"]
    });

    $("#btn-simpan").click(function () {
        let formData = new FormData($('#form-buku')[0]);

        $.ajax({
            type: "POST",
            url: "<?= site_url('data-buku/save') ?>",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function (data) {
                if (data.status) location.reload();
            }
        });
        return false;
    });

    $("#btn-update").click(function () {
        let formData = new FormData($('#form-buku')[0]);

        $.ajax({
            type: "POST",
            url: "<?= site_url('data-buku/update') ?>",
            data: formData,
            contentType: false,
            processData: false,
            dataType: "JSON",
            success: function (data) {
                if (data.status) location.reload();
            }
        });
        return false;
    });

    $("#btn-refresh").click(function () {
        location.reload();
    });

    /* =============================
       PILIH BUKU (UNTUK PEMINJAMAN)
       ============================= */
    $(document).on('click', '.pilih-buku', function () {
        let id = $(this).data('id');

        $.ajax({
            type: "POST",
            url: "<?= site_url('tambahBuku') ?>",
            data: { id_buku: id },
            dataType: "JSON",
            success: function (res) {
                if (res.status) {
                    alert('Buku dipilih');
                } else {
                    alert(res.msg);
                }
            }
        });
    });
});

function edit(id) {
    $.ajax({
        type: "GET",
        url: "<?= site_url('data-buku/edit') ?>/" + id,
        dataType: "JSON",
        success: function (data) {
            $("#btn-simpan").hide();
            $("#btn-update").show();
            $("#btn-refresh").show();

            $("#id_buku").val(data.id);
            $("#kode_buku").val(data.kode_buku);
            $("#judul").val(data.judul);
            $("#pengarang").val(data.pengarang);
            $("#penerbit").val(data.penerbit);
            $("#tahun").val(data.tahun);
            $("#stok").val(data.stok);
        }
    });
}

function hapus(id) {
    $.ajax({
        type: "GET",
        url: "<?= site_url('data-buku/hapus') ?>/" + id,
        dataType: "JSON",
        success: function () {
            location.reload();
        }
    });
}
</script>
