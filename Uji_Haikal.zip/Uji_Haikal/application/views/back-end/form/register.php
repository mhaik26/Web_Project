<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <title>Registrasi Anggota</title> 
 
  <!-- Google Font: Source Sans Pro --> 
  <link rel="stylesheet" 
href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"> 
  <!-- Font Awesome --> 
  <link rel="stylesheet" href="<?=base_url()?>assets/plugins/fontawesomefree/css/all.min.css"> 
  <!-- Tempusdominus Bootstrap 4 --> 
  <link rel="stylesheet" href="<?=base_url()?>assets/plugins/tempusdominusbootstrap-4/css/tempusdominus-bootstrap-4.min.css"> 
  <!-- iCheck --> 
  <!-- JQVMap --> 
  <link rel="stylesheet" href="<?=base_url()?>assets/dist/css/adminlte.min.css"> 
  <!-- overlayScrollbars --> 
</head> 
<body class="hold-transition sidebar-mini layout-fixed bg-dark"> 
 <div class="wrapper" style="color:#000"> 
 
  <section class="content-header"> 
   <div class="container-fluid"> 
    <div class="row d-flex justify-content-center"> 
     <div class="col-lg-4 col-12 "> 
      <div class="card card-primary"> 
       <div class="card-header textcenter"> 
        <h3 class="card-title"><i class="fa fa-user"></i> Registrasi Anggota</h3> 
       </div> 
       <div class="card-body"> 
        <div class="row"> 
         <div class="col-lg12"> 
          <form id="form-anggota"> 
           <div class="form-group"> 
              <label for="exampleInputBorder">Nis</label> 
              <input type="text" class="form-control form-control-sm form-controlborder" id="nis" name="nis"> 
              <input type="hidden" class="form-control form-control-sm form-controlborder" id="id_siswa" name="id_siswa"> 
              <input type="hidden" class="form-control form-control-sm form-controlborder" id="user_id" name="user_id"> 
            </div> 
           <div class="form-group"> 
              <label for="exampleInputBorder">Nama Siswa</label> 
              <input type="text" class="form-control form-control-sm form-controlborder" id="nm_siswa" name="nm_siswa"> 
            </div> 
            <div class="form-group"> 
              <label for="exampleInputBorder">Kelas</label> 
              <input type="text" class="form-control form-control-sm form-controlborder" id="kelas" name="kelas"> 
            </div> 
            <div class="form-group"> 
              <label for="exampleInputBorder">Alamat</label> 
              <textarea class="form-control form-control-sm form-control-border" id="alamat" name="alamat"></textarea> 
              <hr>
              <code>** Pembuatan User Anggota</code> 
            </div> 
            <div class="form-group"> 
              <label for="exampleInputBorder">Username</label> 
              <input type="text" class="form-control form-control-sm form-controlborder" id="username" name="username"> 
            </div> 
            <div class="form-group"> 
              <label for="exampleInputBorder">Password</label> 
              <input type="password" class="form-control form-control-sm formcontrol-border" id="password" name="password" autocomplete="newpassword"> 
            </div> 
          </form> 
          <div class="form-group d-flex justify-content-end"> 
            <button class="btn btn-sm btn-primary btn-block" id="btn-simpan"><i class="fa fa-save"></i> Proses Registrasi</button> 
          </div> 
          <div class="form-group d-flex justify-content-end"> 
           <a href="<?=site_url('login-sistem')?>" class="btn btn-sm btn-dark btn-block"><i class="fa fa-user"></i> Login Anggota</a> 
          </div> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
  </section> 
 </div> 
 <script src="<?=base_url()?>assets/plugins/jquery/jquery.min.js"></script> 
 <script src="<?=base_url()?>assets/plugins/jquery-ui/jqueryui.min.js"></script> 
 <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip --> 
 <script> 
   $.widget.bridge('uibutton', $.ui.button) 
 </script> 
 <!-- Bootstrap 4 --> 
 <script src="<?=base_url()?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script> 
 <script src="<?=base_url()?>assets/plugins/moment/moment.min.js"></script> 
 <!-- AdminLTE App --> 
 
 
<script type="text/javascript"> 
 $(document).ready(function(){ 
  $("#btn-simpan").click(function(){ 
   var formData = new FormData($('#form-anggota')[0]); 
   if($("#username").val() == "" || $("#password").val() == ""){ 
    alert("Username dan Password wajib di isi"); 
    return false; 
   } 
 
 
     $.ajax({ 
      type: "POST", 
      url: "<?php echo site_url('registrasi/save')?>", 
      data: formData, 
      contentType: false, 
      processData: false, 
      dataType: "JSON", 
      success: function(data) { 
       if(data.status) { 
        alert("Anda berhasil menjadi anggota perpustakaan SMK Al Bahri"); 
        window.location.href = "<?=site_url()?>login-sistem"; 
       } 
      } 
     }); 
     return false; 
  }) 
 }); 
</script> 
</body> 
</html>