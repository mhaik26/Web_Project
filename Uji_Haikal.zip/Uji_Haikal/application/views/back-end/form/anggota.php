<section class="content-header">
    <div class="container-fluid">
        <div class="card card-primary">

            <div class="card-header">
                <h3 class="card-title">Data Anggota Perpustakaan</h3>
            </div>

            <div class="card-body">
                <div class="row">

                    <!-- FORM -->
                    <div class="col-lg-4">
                        <form id="form-anggota">

                            <div class="form-group">
                                <label>NIS</label>
                                <input type="text" class="form-control form-control-sm form-control-border" name="nis" id="nis">
                                <input type="hidden" name="id_siswa" id="id_siswa">
                                <input type="hidden" name="user_id" id="user_id">
                            </div>

                            <div class="form-group">
                                <label>Nama Siswa</label>
                                <input type="text" class="form-control form-control-sm form-control-border" name="nm_siswa" id="nm_siswa">
                            </div>

                            <div class="form-group">
                                <label>Kelas</label>
                                <input type="text" class="form-control form-control-sm form-control-border" name="kelas" id="kelas">
                            </div>

                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control form-control-sm form-control-border" name="alamat" id="alamat"></textarea>
                                <hr>
                                <code>** Pembuatan User Anggota</code>
                            </div>

                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" class="form-control form-control-sm form-control-border" name="username" id="username">
                            </div>

                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control form-control-sm form-control-border" name="password" id="password">
                            </div>

                        </form>

                        <div class="form-group d-flex justify-content-end">
                            <button class="btn btn-sm btn-primary" id="btn-simpan">
                                <i class="fa fa-save"></i> Simpan Data
                            </button>

                            <button class="btn btn-sm btn-primary ml-1" id="btn-update" style="display:none;">
                                <i class="fa fa-save"></i> Update Data
                            </button>

                            <button class="btn btn-sm btn-success ml-1" id="btn-refresh" style="display:none;">
                                <i class="fa fa-retweet"></i> Refresh
                            </button>
                        </div>
                    </div>

                    <!-- TABLE -->
                    <div class="col-lg-8">
                        <div class="table-responsive">
                            <table id="DataTables" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no=1; foreach($result as $rs): ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $rs->nis ?></td>
                                        <td><?= $rs->nama ?></td>
                                        <td><?= $rs->alamat ?></td>
                                        <td>
                                            <div id="status_anggota<?= $rs->id ?>">
                                                <?php if($rs->status == 'aktif'): ?>
                                                    <button class="btn btn-sm btn-success" onclick="status('<?= $rs->id ?>')">Aktif</button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-danger" onclick="status('<?= $rs->id ?>')">Non Aktif</button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary" onclick="edit('<?= $rs->id ?>')">
                                                <i class="fa fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="hapus('<?= $rs->user_id ?>')">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<script>
$(document).ready(function(){

    $('#DataTables').DataTable({
        paging:true,
        ordering:false,
        responsive:true
    });

    // SIMPAN
    $('#btn-simpan').click(function(){
        let formData = new FormData($('#form-anggota')[0]);

        if($('#username').val()=='' || $('#password').val()==''){
            alert('Username & Password wajib diisi');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'<?= site_url('data-anggota/save') ?>',
            data:formData,
            contentType:false,
            processData:false,
            dataType:'JSON',
            success:function(res){
                if(res.status) location.reload();
            }
        });
        return false;
    });

    // UPDATE
    $('#btn-update').click(function(){
        let formData = new FormData($('#form-anggota')[0]);

        $.ajax({
            type:'POST',
            url:'<?= site_url('data-anggota/update') ?>',
            data:formData,
            contentType:false,
            processData:false,
            dataType:'JSON',
            success:function(res){
                if(res.status) location.reload();
            }
        });
        return false;
    });

    $('#btn-refresh').click(function(){
        location.reload();
    });

});

        // EDIT
        function edit(id){
            $.getJSON('<?= site_url('data-anggota/edit/') ?>'+id,function(res){
                $('#btn-simpan').hide();
                $('#btn-update,#btn-refresh').show();

                $('#id_siswa').val(res.id);
                $('#user_id').val(res.user_id);
                $('#nis').val(res.nis);
                $('#nm_siswa').val(res.nama);
                $('#kelas').val(res.kelas);
                $('#alamat').val(res.alamat);
                $('#username').val(res.username);
            });
        }

        // HAPUS
        function hapus(user_id){
            if(confirm('Hapus data?')){
                $.getJSON('<?= site_url('data-anggota/hapus/') ?>'+user_id,function(){
                    location.reload();
                });
            }
        }

        // STATUS
        function status(id){
            $.get('<?= site_url('data-anggota/status/') ?>'+id,function(html){
                $('#status_anggota'+id).html(html);
            });
        }
        </script>
