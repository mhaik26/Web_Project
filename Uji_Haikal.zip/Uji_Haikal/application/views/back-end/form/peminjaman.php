<section class="content-header">
    <div class="container-fluid">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Data Peminjaman Buku</h3>
            </div>

            <div class="card-body">
                <div class="row">

                    <div class="col-lg-4">
                        <form id="formpeminjaman">

                            <div class="formgroup">
                                <label>No Peminjaman</label>
                                <input type="text"
                                       class="form-control form-control-sm form-controlborder"
                                       id="no_pinjam"
                                       name="no_pinjam">
                            </div>

                            <div class="formgroup">
                                <label>Data Anggota</label>
                                <div class="input-group input-group-sm">
                                    <input type="text"
                                           class="form-control form-control-sm form-control-border"
                                           name="nm_siswa"
                                           id="nm_siswa"
                                           readonly>
                                    <input type="hidden"
                                           class="form-control form-control-sm form-control-border"
                                           name="anggota_id"
                                           id="anggota_id"
                                           readonly>
                                    <span class="input-group-append">
                                        <button type="button"
                                                class="btn btn-info btn-flat"
                                                id="btn_list_anggota"
                                                onclick="anggota();">
                                            Go
                                        </button>
                                    </span>
                                </div>
                            </div>

                            <div class="formgroup">
                                <label>Tanggal Pinjam</label>
                                <input type="date"
                                       class="form-control form-control-sm form-controlborder"
                                       id="tgl_pinjam"
                                       name="tgl_pinjam">
                            </div>

                            <div class="formgroup">
                                <label>Tanggal Kembali</label>
                                <input type="date"
                                       class="form-control form-control-sm form-controlborder"
                                       id="tgl_kembali"
                                       name="tgl_kembali">
                            </div>

                        </form>
                    </div>

                    <div class="col-lg-8">
                        <div class="form-group">
                            <code>** Silahkan untuk menambahkan daftar buku yang akan di pinjam</code>
                            <a href="javascript:void(0);"
                               class="btn btn-sm btn-dark"
                               onclick="buku();">
                                <i class="fa fa-plus"></i> List Buku
                            </a>
                        </div>

                        <div class="tableresponsive">
                            <table id="DataTables"
                                   class="table table-striped"
                                   style="width:100%">
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center">Detail Peminjaman</th>
                                        <th class="text-center">Qty</th>
                                        <th class="text-center" width="15%">#</th>
                                    </tr>
                                </thead>
                                <tbody id="viewListBuku"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <hr>
                        <div class="d-flex justifycontent-end">
                            <button class="btn btn-sm btn-primary" id="btn-simpan">
                                <i class="fa fa-save"></i> Proses Peminjaman
                            </button>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- MODAL ANGGOTA -->
<div class="modal fade" id="modalListAnggota">
    <div class="modal-dialog modal-lg" style="max-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">LIST ANGGOTA</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="table-responsive">
                    <table id="DataTablesAnggota" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">NIS</th>
                                <th class="text-center">Nama Siswa</th>
                                <th class="text-center">Kelas</th>
                                <th class="text-center">Alamat</th>
                                <th class="text-center">#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($resultAnggota as $rs) {
                                $no = 1;
                                echo '
                                <tr>
                                    <td class="text-center">'.$no.'</td>
                                    <td class="text-center">'.$rs->nis.'</td>
                                    <td>'.$rs->nama.'</td>
                                    <td>'.$rs->kelas.'</td>
                                    <td>'.$rs->alamat.'</td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-primary"
                                            onclick="pilihAnggota(\''.$rs->id.'\', \''.$rs->nama.'\')">
                                            <i class="fa fa-check"></i> Pilih
                                        </button>
                                    </td>
                                </tr>';
                                $no++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL BUKU -->
<div class="modal fade" id="modalListBuku">
    <div class="modal-dialog modal-lg" style="max-width:90%;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">LIST BUKU</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="table-responsive">
                    <table id="DataTablesBuku" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Kode Buku</th>
                                <th class="text-center">Tahun</th>
                                <th class="text-center">Stok</th>
                                <th class="text-center">#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($resultBuku as $rs) {
                                $no = 1;
                                echo '
                                <tr>
                                    <td>'.$no.'</td>
                                    <td>
                                        '.$rs->kode_buku.'<br>
                                        '.$rs->judul.'<br>
                                        '.$rs->pengarang.'<br>
                                        '.$rs->penerbit.'
                                    </td>
                                    <td>'.$rs->tahun.'</td>
                                    <td>'.$rs->stok.'</td>
                                    <td>
                                        <button class="btn btn-sm btn-primary"
                                            onclick="pilihBuku(\''.$rs->id.'\')">
                                            <i class="fa fa-check"></i> Pilih
                                        </button>
                                    </td>
                                </tr>';
                                $no++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {

    $('#btn-simpan').click(function (e) {
        e.preventDefault();

        var formData = new FormData($('#formpeminjaman')[0]);

        if (
            $('#no_pinjam').val() === '' ||
            $('#nm_siswa').val() === '' ||
            $('#tgl_pinjam').val() === '' ||
            $('#tgl_kembali').val() === ''
        ) {
            alert('Data wajib di isi');
            return false;
        }

        $.ajax({
            type: 'POST',
            url: "<?= site_url('data-peminjaman/save') ?>", // <<< INI DOANG YANG ERROR
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'JSON',
            success: function (res) {
                if (res.status === true) {
                    alert('Data peminjaman buku berhasil');
                    location.reload();
                } else {
                    alert('Gagal menyimpan data');
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
                alert('ERROR AJAX SAVE');
            }
        });

        return false;
    });

});

function anggota() {
    $('#modalListAnggota').modal('show');
}

function buku() {
    $('#modalListBuku').modal('show');
}

function pilihAnggota(id, nama) {
    $('#nm_siswa').val(nama);
    $('#anggota_id').val(id);
    $('#modalListAnggota').modal('toggle');
}

function pilihBuku(id) {
    $.ajax({
        type: 'POST',
        url: "<?= site_url('data-peminjaman/tambah-buku') ?>",
        data: { id_buku: id },
        dataType: 'JSON',
        success: function (res) {
            if (res.Pesan) {
                alert(res.Pesan);
            } else {
                viewBuku();
                $('#modalListBuku').modal('hide');
            }
        },
        error: function (xhr) {
            console.log(xhr.responseText);
            alert('ERROR AJAX');
        }
    });
}

function viewBuku() {
    $.ajax({
        type: 'GET',
        url: "<?= site_url('data-peminjaman/list-buku') ?>",
        success: function (html) {
            $('#viewListBuku').html(html);
        }
    });
}

function hapusBuku(id) {
    $.ajax({
        type: 'GET',
        url: "<?= site_url('data-peminjaman/hapus-buku') ?>/" + id,
        dataType: 'JSON',
        success: function () {
            viewBuku();
        }
    });
}
</script>
