<!-- Main content -->
<section class="content">
    <div class="container-fluid text-center font-weight-bold">
        <h1>SISTEM APLIKASI PEMINJAMAN DAN PENGEMBALIAN BUKU <br>SMK AL BAHRI KOTA BEKASI</h1>
        <div class="p-3">
            <img src="<?= base_url() ?>images/perpus.png" class="img-fluid" alt="Perpustakaan SMK Al Bahri">
        </div>
    </div>
</section>
<!-- /.content -->