<?php $role = $this->session->userdata('level'); ?>

<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <!-- Brand Logo -->
    <span class="brand-link">
        <img src="<?= base_url() ?>images/karyawan/monkey.jpg"
             alt="AdminLTE Logo"
             class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span class="brand-text font-weight-light">Perpustakaan</span>
    </span>

    <!-- Sidebar -->
    <div class="sidebar">

        <!-- User Panel -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?= base_url() ?>images/karyawan/rawr.jpg"
                     class="img-circle elevation-2"
                     alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">KASI-R</a>
            </div>
        </div>

        <!-- Search -->
        <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar"
                       type="search"
                       placeholder="Search"
                       aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                        <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column"
                data-widget="treeview"
                role="menu"
                data-accordion="false">

                <!-- Home -->
                <li class="nav-item">
                    <a href="<?= site_url() ?>" class="nav-link active">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Home</p>
                    </a>
                </li>

                <!-- Admin Menu -->
                <?php if ($role == "admin"): ?>
                    <li class="nav-item">
                        <a href="<?= site_url('data-anggota') ?>" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>Data Anggota</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?= site_url('data-buku') ?>" class="nav-link">
                            <i class="nav-icon fas fa-book"></i>
                            <p>Data Buku</p>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Transaksi -->
                <?php if ($role == "admin" || $role == "siswa"): ?>
                    <li class="nav-header">TRANSAKSI</li>
                    <li class="nav-item">
                        <a href="<?= site_url('data-riwayat') ?>" class="nav-link">
                            <i class="nav-icon fas fa-tags"></i>
                            <p>Data Riwayat Peminjaman</p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($role == "admin"): ?>
                    <li class="nav-item">
                        <a href="<?= site_url('data-peminjaman') ?>" class="nav-link">
                            <i class="nav-icon fas fa-tags"></i>
                            <p>Data Peminjaman</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?= site_url('data-pengembalian') ?>" class="nav-link">
                            <i class="nav-icon fas fa-tags"></i>
                            <p>Data Pengembalian</p>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Setting -->
                <li class="nav-header">SETTING</li>
                <li class="nav-item">
                    <a href="<?= site_url('logout-sistem') ?>" class="nav-link">
                        <i class="nav-icon far fa-user"></i>
                        <p>Logout</p>
                    </a>
                </li>

            </ul>
        </nav>

    </div>
</aside>
