<!-- jQuery -->
<script src="<?=base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?=base_url()?>assets/jquery.PrintArea.js"></script>


<div class="content-wrapper">
    <?php
    $this->load->view('back-end/'.$content);
    ?>
</div