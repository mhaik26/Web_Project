<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('anggota_model','mdl');
    }

    function index()
    {
        $this->load->view('back-end/form/register');
    }

    function save()
    {
        // 🔐 HASH PASSWORD (INI YANG HILANG KEMARIN)
        $password = password_hash(
            $this->input->post("password"),
            PASSWORD_DEFAULT
        );

        $data = array(
            'nama'     => $this->input->post("nm_siswa"),
            'username' => $this->input->post("username"),
            'password' => $password,   // ← FIX
            'role'     => 'anggota',    // samain sama data admin
        );

        $id_user = $this->mdl->simpan_data($data);

        if ($id_user) {

            $dataAnggota = array(
                'user_id' => $id_user,
                'nis'     => $this->input->post("nis"),
                'kelas'   => $this->input->post("kelas"),
                'alamat'  => $this->input->post("alamat"),
            );

            $this->mdl->simpan_data_anggota($dataAnggota);

            echo json_encode(array("status" => true));
        } else {
            echo json_encode(array("status" => false));
        }
    }
}
