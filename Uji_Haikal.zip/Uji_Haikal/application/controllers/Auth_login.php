<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Auth_login extends CI_Controller { 
    public function __construct() { 
        parent::__construct(); 
    } 
    public function index() { 
        if ($this->session->userdata('logged') == true) { 
            redirect(site_url('halaman-sistem')); 
        }else{ 
            $data['admin'] = ""; 
            $this->load->view('back-end/layout/login', $data); 
        } 
    }    
    public function login() { 
        $username = $this->input->post('username'); 
        $password = $this->input->post('password');
        $where = "users.username='$username'"; 
        $result = $this->db 
                        ->from('users') 
                        ->where($where) 
                        ->limit(1) 
                        ->get(); 
        if ($result->num_rows() == 0) { 
            //return false; 
            echo "salah"; 
        } else { 
            $data = $result->row(); 
            if (password_verify($password, $data->password)) { 
                $session_data = [ 
                    'id_user' => $data->id, 
                    'username' => $data->username, 
                    'level' => $data->role, 
                    'logged' => TRUE, 
                    'nama' => $data->nama 
                ]; 
 
                $this->session->set_userdata($session_data); 
                redirect('halaman-sistem'); 
                echo "berhasil"; 
            }else{ 
                redirect('login-sistem'); 
                echo "berhasil"; 
            } 
        } 
    } 
 
    public function logout() { 
        $this->session->sess_destroy(); 
        redirect(site_url('login-sistem')); 
    } 
} 
