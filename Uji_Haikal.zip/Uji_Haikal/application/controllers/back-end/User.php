<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    function save()
    {
        $data = array(
            "nama" => 'admin',
            "username"  => 'admin',
            "role"     => 'Admin',
            "password"     => password_hash('admin',PASSWORD_DEFAULT),
        );

        $data = array(
            "nama" => 'Haikal',
            "username"  => 'Haikal',
            "role"     => 'Anggota',
            "password"     => password_hash('anggota',PASSWORD_DEFAULT),
        );

        $this->db->insert('users',$data);
    }
}