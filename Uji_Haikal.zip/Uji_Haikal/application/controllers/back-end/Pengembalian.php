<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengembalian extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('logged') <> 1) {
            redirect(site_url('login-sistem'));
        } else {
            $this->load->model('pengembalian_model', 'mdl');
        }
    }

    function index()
    {
        $this->load->library('template_adminlte');

        $data = array(
            'content'          => 'form/pengembalian',
            'resultPeminjaman' => $this->mdl->findPeminjaman(),
        );

        $this->template_adminlte->display('index', $data);
    }

    function peminjaman($id)
    {
        $row = $this->mdl->findPeminjamanById($id);
        echo json_encode($row);
    }

    function viewDetailPeminjaman($id)
    {
        $peminjamanDetail = $this->mdl->findPeminjamanDetail($id);

        if ($peminjamanDetail) {
            $no = 1;
            foreach ($peminjamanDetail as $rs) {
                echo '
                <tr>
                    <td class="text-center">'.$no.'</td>
                    <td>
                        '.$rs->kode_buku.'<br>
                        Judul: '.$rs->judul.'<br>
                        Pengarang: '.$rs->pengarang.'<br>
                        Penerbit: '.$rs->penerbit.'
                    </td>
                    <td class="text-center">'.$rs->qty.'</td>
                </tr>
                ';
                $no++;
            }
        }
    }

    function save()
    {
        $data = array(
            'peminjaman_id'    => $this->input->post("peminjaman_id"),
            'tgl_pengembalian' => $this->input->post("tgl_pengembalian"),
            'denda'            => $this->input->post("denda"),
        );

        $query = $this->mdl->simpan_data($data);

        if ($query) {

            $data = array(
                'status' => 'dikembalikan',
            );

            $this->db->where('id', $this->input->post("peminjaman_id"));
            $query = $this->db->update('peminjaman', $data);

            if ($query) {

                $peminjamanDetail = $this->mdl
                    ->findPeminjamanDetail($this->input->post("peminjaman_id"));

                foreach ($peminjamanDetail as $rs) {

                    $qty = $rs->qty;

                    // Perubahan data stok di data barang
                    $this->db->query("
                        UPDATE buku 
                        SET stok = stok + $qty 
                        WHERE id = '".$rs->buku_id."'
                    ");
                }

                echo json_encode(array("status" => TRUE));
            }
        }
    }
}
