<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggota extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('logged')) {
            redirect(site_url('login-sistem'));
        } else {
            $this->load->model('anggota_model', 'mdl');
        }
    }

    public function index()
    {
        $this->load->library('template_adminlte');

        $data = array(
            'content' => 'form/anggota',
            'result'  => $this->mdl->find(),
        );

        $this->template_adminlte->display('index', $data);
    }

    public function save()
    {
        $data = array(
            'nama'     => $this->input->post("nm_siswa"),
            'username' => $this->input->post("username"),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'role'     => 'siswa',
        );

        $id_user = $this->mdl->simpan_data($data);

        if ($id_user) {

            $dataAnggota = array(
                'user_id' => $id_user,
                'nis'     => $this->input->post("nis"),
                'kelas'   => $this->input->post("kelas"),
                'alamat'  => $this->input->post("alamat"),
            );

            $this->mdl->simpan_data_anggota($dataAnggota);
            echo json_encode(array("status" => TRUE));

        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function update()
    {
        $data = array(
            'nama'     => $this->input->post("nm_siswa"),
            'username' => $this->input->post("username"),
            'role'     => 'siswa',
        );

        if ($this->input->post('password') != "") {
            $data['password'] = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
        }

        $update_user = $this->mdl->update_user(
            $this->input->post('user_id'),
            $data
        );

        if ($update_user) {

            $dataAnggota = array(
                'nis'    => $this->input->post("nis"),
                'kelas'  => $this->input->post("kelas"),
                'alamat' => $this->input->post("alamat"),
            );

            $this->mdl->update_anggota(
                $this->input->post('id_siswa'),
                $dataAnggota
            );

            echo json_encode(array("status" => TRUE));

        } else {
            echo json_encode(array("status" => FALSE));
        }
    }

    public function edit($id)
    {
        $data = $this->mdl->findById($id);
        echo json_encode($data);
    }

    public function hapus($user_id)
    {
        $this->mdl->delete($user_id);
        echo json_encode(array("status" => TRUE));
    }

    public function status($id)
    {
        $row = $this->mdl->findById($id);

        if ($row->status == "aktif") {
            $data = array('status' => 'nonaktif');
        } else {
            $data = array('status' => 'aktif');
        }

        $this->mdl->update_anggota($id, $data);
        $row = $this->mdl->findById($id);

        if ($row->status == 'nonaktif') {
            $aktif = '
            <button class="btn btn-sm btn-danger" id="btn-status"
                onClick="status(\''.$row->id.'\')">
                <i class="fa fa-eye-slash p-1" aria-hidden="true"></i> Non Aktif
            </button>';
        } else {
            $aktif = '
            <button class="btn btn-sm btn-success" id="btn-status"
                onClick="status(\''.$row->id.'\')">
                <i class="fa fa-eye p-1" aria-hidden="true"></i> Aktif
            </button>';
        }

        echo $aktif;
    }
}
