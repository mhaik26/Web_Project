<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('logged') <> 1) {
            redirect(site_url('login-sistem'));
        } else {
            $this->load->model('peminjaman_model', 'mdl');
        }
    }

    function index()
    {
        $this->load->library('template_adminlte');
        $this->session->unset_userdata('cart_peminjaman');

        $data = array(
            'content'       => 'form/peminjaman',
            'resultAnggota' => $this->mdl->findAnggota(),
            'resultBuku'    => $this->mdl->findBuku(),
        );

        $this->template_adminlte->display('index', $data);
    }

    function tambahBuku()
    {
        $buku_id = $this->input->post('id_buku');

        $buku = $this->db
            ->get_where('buku', ['id' => $buku_id])
            ->row();

        $cart = $this->session->userdata('cart_peminjaman') ?? [];

        if ($buku->stok > 1) {

            $cart[$buku_id] = [
                'buku_id'   => $buku->id,
                'kode_buku' => $buku->kode_buku,
                'judul'     => $buku->judul,
                'pengarang' => $buku->pengarang,
                'penerbit'  => $buku->penerbit,
                'tahun'     => $buku->tahun,
                'qty'       => 1
            ];

            $this->session->set_userdata('cart_peminjaman', $cart);
            echo json_encode($cart);

        } else {
            echo json_encode(array(
                "Pesan" => "Buku saat ini tidak tersedia atau sudah di pinjam semua"
            ));
        }
    }

    function viewListBuku()
    {
        $cart = $this->session->userdata('cart_peminjaman');

        if ($cart) {
            $no = 1;

            foreach ($cart as $rs) {
                echo '
                <tr>
                    <td class="text-center">' . $no . '</td>
                    <td>
                        ' . $rs['kode_buku'] . '<br>
                        Judul: ' . $rs['judul'] . '<br>
                        Pengarang: ' . $rs['pengarang'] . '<br>
                        Penerbit: ' . $rs['penerbit'] . '<br>
                        Tahun: ' . $rs['tahun'] . '
                    </td>
                    <td class="text-center">' . $rs['qty'] . '</td>
                    <td>
                        <button class="btn btn-sm btn-danger"
                            onclick="hapusBuku(' . "'" . $rs['buku_id'] . "'" . ')">
                            <i class="fa fa-trash"></i>
                        </button>
                    </td>
                </tr>
                ';
                $no++;
            }
        }
    }

    function hapusBuku($buku_id)
    {
        $cart = $this->session->userdata('cart_peminjaman');
        unset($cart[$buku_id]);

        $this->session->set_userdata('cart_peminjaman', $cart);
        echo json_encode(array("status" => TRUE));
    }

    function save()
    {
        $data = array(
            'no_peminjaman' => $this->input->post("no_pinjam"),
            'anggota_id'    => $this->input->post("anggota_id"),
            'tgl_pinjam'    => $this->input->post("tgl_pinjam"),
            'tgl_kembali'   => $this->input->post("tgl_kembali"),
        );

        $peminjaman_id = $this->mdl->simpan_data_peminjaman($data);

        if ($peminjaman_id) {

            $cart = $this->session->userdata('cart_peminjaman');

            foreach ($cart as $rs) {

                $data = array(
                    'peminjaman_id' => $peminjaman_id,
                    'buku_id'       => $rs['buku_id'],
                    'qty'           => $rs['qty'],
                );

                $query = $this->db->insert('peminjaman_detail', $data);

                if ($query) {
                    $qty = $rs['qty'];
                    // Perubahan data stok di data barang
                    $this->db->query(
                        "UPDATE buku SET stok = stok - $qty WHERE id = '" . $rs['buku_id'] . "'"
                    );
                }
            }

            echo json_encode(array("status" => TRUE));

        } else {
            echo json_encode(array("status" => false));
        }
    }

    function hapus($peminjaman_id)
    {
        $query = $this->mdl->delete($peminjaman_id);
        echo json_encode(array("status" => TRUE));
    }
}
