<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('logged') != 1) {
            redirect(site_url('login-sistem'));
        }

        $this->load->model('buku_model', 'mdl');
    }

    public function index()
    {
        $this->load->library('template_adminlte');

        $data = [
            'content' => 'form/buku',
            'result'  => $this->mdl->find(),
        ];

        $this->template_adminlte->display('index', $data);
    }

    public function save()
    {
        $data = [
            'kode_buku' => $this->input->post('kode_buku'),
            'judul'     => $this->input->post('judul'),
            'pengarang' => $this->input->post('pengarang'),
            'penerbit'  => $this->input->post('penerbit'),
            'tahun'     => $this->input->post('tahun'),
            'stok'      => $this->input->post('stok'),
        ];

        $query = $this->mdl->simpan_data($data);

        echo json_encode([
            'status' => $query ? true : false
        ]);
    }

    public function update()
    {
        $data = [
            'kode_buku' => $this->input->post('kode_buku'),
            'judul'     => $this->input->post('judul'),
            'pengarang' => $this->input->post('pengarang'),
            'penerbit'  => $this->input->post('penerbit'),
            'tahun'     => $this->input->post('tahun'),
            'stok'      => $this->input->post('stok'),
        ];

        $this->mdl->update($this->input->post('id_buku'), $data);

        echo json_encode(['status' => true]);
    }

    public function edit($id)
    {
        $data = $this->mdl->findById($id);
        echo json_encode($data);
    }

    public function hapus($id)
    {
        $this->mdl->delete($id);
        echo json_encode(['status' => true]);
    }

    /* ============================
       INI YANG BIKIN TOMBOL PILIH BISA
       ============================ */
    public function tambahBuku()
    {
        $id_buku = $this->input->post('id_buku');

        if (!$id_buku) {
            echo json_encode([
                'status' => false,
                'msg' => 'ID buku kosong'
            ]);
            return;
        }

        $buku = $this->mdl->findById($id_buku);

        if (!$buku) {
            echo json_encode([
                'status' => false,
                'msg' => 'Buku tidak ditemukan'
            ]);
            return;
        }

        echo json_encode([
            'status' => true,
            'data' => $buku
        ]);
    }
}
