<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Riwayat extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('logged') <> 1) {
            redirect(site_url('login-sistem'));
        } else {
            $this->load->model('Riwayat_model', 'mdl');
        }
    }

    public function index()
    {
        $this->load->library('template_adminlte');

        $data = array(
            'content'          => 'form/riwayat',
            'resultPeminjaman' => $this->mdl->findPeminjaman(),
        );

        $this->template_adminlte->display('index', $data);
    }

    public function viewBuku($id)
    {
        $peminjamanDetail = $this->mdl->findPeminjamanDetail($id);

        if ($peminjamanDetail) {
            $no = 1;
            foreach ($peminjamanDetail as $rs) {
                echo '
                <tr>
                    <td class="text-center">'.$no.'</td>
                    <td>
                        '.$rs->kode_buku.'
                        <br>Judul: '.$rs->judul.'
                        <br>Pengarang: '.$rs->pengarang.'
                        <br>Penerbit: '.$rs->penerbit.'
                    </td>
                    <td class="text-center">'.$rs->qty.'</td>
                </tr>
                ';
                $no++;
            }
        }
    }
}
